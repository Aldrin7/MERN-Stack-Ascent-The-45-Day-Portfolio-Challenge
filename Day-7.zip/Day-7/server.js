// Day 7: Your First Server (Node.js & Express)
// Challenge: Create an Express server that listens on port 3000 and responds with JSON

// Import the Express framework
const express = require('express');

// Create an Express application
const app = express();

// Middleware for parsing JSON requests (useful for POST/PUT requests)
app.use(express.json());

// Middleware for parsing URL-encoded data
app.use(express.urlencoded({ extended: true }));

// Add basic logging middleware
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${req.method} ${req.path} - ${req.ip}`);
  next();
});

// Define the /api route (Challenge Requirement)
app.get('/api', (req, res) => {
  console.log('🌟 API endpoint called!');
  res.json({
    message: "API is running!",
    timestamp: new Date().toISOString(),
    status: "success"
  });
});

// Additional routes for learning and testing

// Root route - serves HTML for easy testing
app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Day 7: Express Server</title>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                margin: 0;
                padding: 0;
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .container {
                background: white;
                border-radius: 20px;
                padding: 40px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                text-align: center;
                max-width: 600px;
                margin: 20px;
            }
            h1 {
                color: #6f42c1;
                margin-bottom: 20px;
            }
            .api-link {
                display: inline-block;
                background: linear-gradient(135deg, #6f42c1, #5a32a3);
                color: white;
                padding: 15px 30px;
                text-decoration: none;
                border-radius: 50px;
                font-weight: bold;
                margin: 10px;
                transition: transform 0.2s;
            }
            .api-link:hover {
                transform: translateY(-2px);
            }
            .info {
                background: #f8f9fa;
                padding: 20px;
                border-radius: 10px;
                margin: 20px 0;
                border-left: 4px solid #6f42c1;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🚀 Day 7: Express Server</h1>
            <p><strong>Status:</strong> <span style="color: #28a745;">✅ Server is running successfully!</span></p>

            <div class="info">
                <h3>Test Your API:</h3>
                <a href="/api" class="api-link" target="_blank">📡 GET /api</a>
                <br>
                <small>This will return JSON: <code>{"message": "API is running!"}</code></small>
            </div>

            <div class="info">
                <h3>Server Details:</h3>
                <p><strong>Port:</strong> 3000</p>
                <p><strong>Framework:</strong> Express.js</p>
                <p><strong>Node.js Version:</strong> ${process.version}</p>
                <p><strong>Started:</strong> ${new Date().toLocaleString()}</p>
            </div>

            <p><em>Congratulations! You've successfully created your first Express server! 🎉</em></p>
        </div>
    </body>
    </html>
  `);
});

// Health check route
app.get('/health', (req, res) => {
  res.json({
    status: "healthy",
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    memory: process.memoryUsage()
  });
});

// Info route with server information
app.get('/info', (req, res) => {
  res.json({
    server: "Day 7 Express Server",
    version: "1.0.0",
    description: "Your first Node.js/Express server",
    endpoints: {
      "/": "HTML homepage",
      "/api": "Main API endpoint (Challenge requirement)",
      "/health": "Server health check",
      "/info": "Server information"
    },
    nodeVersion: process.version,
    platform: process.platform,
    uptime: `${Math.floor(process.uptime())} seconds`,
    started: new Date(Date.now() - process.uptime() * 1000).toISOString()
  });
});

// Example route with query parameters
app.get('/greet', (req, res) => {
  const name = req.query.name || 'World';
  res.json({
    message: `Hello, ${name}! Welcome to your Express server!`,
    timestamp: new Date().toISOString()
  });
});

// Example route with route parameters
app.get('/user/:id', (req, res) => {
  const userId = req.params.id;
  res.json({
    userId: userId,
    message: `User ${userId} found!`,
    data: {
      id: userId,
      name: `User ${userId}`,
      email: `user${userId}@example.com`
    }
  });
});

// Example POST route (for future learning)
app.post('/api/echo', (req, res) => {
  res.json({
    message: "Echo endpoint received your data!",
    received: req.body,
    timestamp: new Date().toISOString()
  });
});

// 404 handler for undefined routes
app.use((req, res) => {
  res.status(404).json({
    error: "Route not found",
    message: `The path '${req.path}' does not exist on this server.`,
    availableRoutes: [
      "GET /",
      "GET /api",
      "GET /health",
      "GET /info",
      "GET /greet?name=YourName",
      "GET /user/:id",
      "POST /api/echo"
    ],
    timestamp: new Date().toISOString()
  });
});

// Global error handler
app.use((error, req, res, next) => {
  console.error('❌ Server Error:', error);
  res.status(500).json({
    error: "Internal Server Error",
    message: "Something went wrong on the server",
    timestamp: new Date().toISOString()
  });
});

// Define the port (Challenge requirement: port 3000)
const PORT = process.env.PORT || 3000;

// Start the server (Challenge requirement)
app.listen(PORT, () => {
  console.log('🚀 ==================================================');
  console.log('🎉 Day 7 Challenge: Express Server Started!');
  console.log('🚀 ==================================================');
  console.log(`📡 Server is running on: http://localhost:${PORT}`);
  console.log(`🌐 API endpoint (Challenge): http://localhost:${PORT}/api`);
  console.log(`🏠 Homepage: http://localhost:${PORT}/`);
  console.log(`❤️  Health check: http://localhost:${PORT}/health`);
  console.log(`ℹ️  Server info: http://localhost:${PORT}/info`);
  console.log('🚀 ==================================================');
  console.log('💡 Test your server:');
  console.log(`   curl http://localhost:${PORT}/api`);
  console.log('🚀 ==================================================');
});

// Handle graceful shutdown
process.on('SIGTERM', () => {
  console.log('🛑 SIGTERM received. Shutting down gracefully...');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('🛑 SIGINT received. Shutting down gracefully...');
  process.exit(0);
});

// Export the app for testing (optional)
module.exports = app;

# Day 7 – Your First Server (Node.js & Express)

## Overview
Welcome to the exciting world of back-end development! Today you'll create your first web server using Node.js and Express.js. This marks your transition from front-end development to full-stack development, where you'll learn to build servers that can handle HTTP requests and serve data to clients.

The material covers the fundamentals of server-side programming and provides hands-on experience with creating APIs that power modern web applications.

## What You'll Learn
1. **Back-End vs Front-End** – Understanding server-side vs client-side
2. **Node.js Fundamentals** – Running JavaScript outside the browser
3. **npm Package Management** – Installing and managing dependencies
4. **Express.js Framework** – Building web servers and APIs
5. **HTTP Methods & Routing** – Handling different types of requests
6. **Server Setup & Configuration** – Creating production-ready servers
7. **API Development** – Building endpoints that return JSON data

## Daily Challenge
Create an Express server that meets these specific requirements:

### ✅ Challenge Requirements
- **Create `server.js`** – Main application file
- **Run `npm init -y`** – Initialize the project
- **Install Express** – `npm install express`
- **Port 3000** – Server must listen on port 3000
- **JSON Response** – Return `{"message": "API is running!"}` at `/api` route

### 🎯 Expected Output
```bash
# Terminal output when server starts
🚀 ==================================================
🎉 Day 7 Challenge: Express Server Started!
🚀 ==================================================
📡 Server is running on: http://localhost:3000
🌐 API endpoint (Challenge): http://localhost:3000/api
🏠 Homepage: http://localhost:3000/
🚀 ==================================================

# API Response
GET http://localhost:3000/api
{
  "message": "API is running!",
  "timestamp": "2025-08-28T10:30:00.000Z",
  "status": "success"
}
```

## Quick Start Guide

### Step 1: Set Up Your Project
```bash
# Navigate to Day-7 folder
cd Day-7

# Initialize npm project
npm init -y

# Install Express
npm install express
```

### Step 2: Create Your Server
```javascript
// server.js
const express = require('express');
const app = express();

app.get('/api', (req, res) => {
  res.json({ message: "API is running!" });
});

app.listen(3000, () => {
  console.log('Server running on port 3000');
});
```

### Step 3: Start Your Server
```bash
# Start the server
node server.js

# Or use the npm script
npm start
```

### Step 4: Test Your Server
```bash
# Test the API endpoint
curl http://localhost:3000/api

# Open in browser
# http://localhost:3000/api
# http://localhost:3000/
```

## File Structure
```
Day-7/
├── Day-7-slides.html    # Interactive presentation slides
├── server.js            # Express server implementation
├── package.json         # Project configuration and dependencies
└── README.md           # This file
```

## Key Concepts Explained

### Node.js vs Browser JavaScript

| Feature | Browser JavaScript | Node.js |
|---------|-------------------|---------|
| **Environment** | Browser runtime | Server runtime |
| **APIs** | DOM, XMLHttpRequest | File system, HTTP, TCP |
| **Global Object** | `window` | `global` |
| **Package Management** | None | npm |
| **Use Cases** | UI interactions | Servers, APIs, tools |

### Express.js Architecture

```javascript
// 1. Import Express
const express = require('express');

// 2. Create application instance
const app = express();

// 3. Define routes (middleware)
app.get('/api', (req, res) => {
  res.json({ message: "Hello!" });
});

// 4. Start server
app.listen(3000, () => {
  console.log('Server started!');
});
```

### HTTP Methods & REST

| Method | Purpose | Example |
|--------|---------|---------|
| **GET** | Read data | `GET /api/users` |
| **POST** | Create data | `POST /api/users` |
| **PUT** | Update data | `PUT /api/users/123` |
| **DELETE** | Delete data | `DELETE /api/users/123` |

## Advanced Features (Included)

Your server includes additional routes for learning:

### 🏠 Homepage Route (`/`)
- Returns an HTML page with server information
- Perfect for testing if your server is running
- Includes links to test all endpoints

### ❤️ Health Check (`/health`)
```json
{
  "status": "healthy",
  "uptime": 3600,
  "timestamp": "2025-08-28T10:30:00.000Z",
  "memory": {
    "rss": 25427968,
    "heapTotal": 7159808,
    "heapUsed": 5164192,
    "external": 861344
  }
}
```

### ℹ️ Server Info (`/info`)
```json
{
  "server": "Day 7 Express Server",
  "version": "1.0.0",
  "endpoints": {
    "/": "HTML homepage",
    "/api": "Main API endpoint",
    "/health": "Health check",
    "/info": "Server information"
  }
}
```

### 🎭 Dynamic Routes

#### Query Parameters (`/greet?name=John`)
```bash
curl "http://localhost:3000/greet?name=John"
```
```json
{
  "message": "Hello, John! Welcome to your Express server!",
  "timestamp": "2025-08-28T10:30:00.000Z"
}
```

#### Route Parameters (`/user/123`)
```bash
curl http://localhost:3000/user/123
```
```json
{
  "userId": "123",
  "message": "User 123 found!",
  "data": {
    "id": "123",
    "name": "User 123",
    "email": "user123@example.com"
  }
}
```

### 📨 POST Endpoint (`/api/echo`)
```bash
curl -X POST http://localhost:3000/api/echo \
  -H "Content-Type: application/json" \
  -d '{"name": "John", "age": 30}'
```
```json
{
  "message": "Echo endpoint received your data!",
  "received": {
    "name": "John",
    "age": 30
  },
  "timestamp": "2025-08-28T10:30:00.000Z"
}
```

## Testing Your Server

### Method 1: Browser
1. Start your server: `node server.js`
2. Open browser to: `http://localhost:3000/`
3. Click the "GET /api" button
4. View JSON response in new tab

### Method 2: Command Line
```bash
# Test homepage
curl http://localhost:3000/

# Test API endpoint
curl http://localhost:3000/api

# Test with formatting
curl http://localhost:3000/api | jq
```

### Method 3: Postman/Insomnia
1. Create new request
2. Set method to GET
3. Enter URL: `http://localhost:3000/api`
4. Send request and view response

## Development Workflow

### Using nodemon (Recommended)
```bash
# Install nodemon globally
npm install -g nodemon

# Or install as dev dependency
npm install --save-dev nodemon

# Run with auto-restart
nodemon server.js

# Or use the npm script
npm run dev
```

### Hot Reloading Benefits
- **Auto-restart** when files change
- **Faster development** cycle
- **Better debugging** experience
- **No manual server restarts**

## Error Handling & Debugging

### Common Issues

#### ❌ "Cannot find module 'express'"
```bash
# Solution: Install Express
npm install express
```

#### ❌ "Port 3000 already in use"
```bash
# Find process using port 3000
lsof -i :3000

# Kill the process
kill -9 <PID>

# Or use different port
PORT=3001 node server.js
```

#### ❌ "SyntaxError: Unexpected token"
- Check for missing commas in JSON
- Verify all parentheses are closed
- Look for typos in variable names

### Debug Mode
```bash
# Run with debug logging
DEBUG=express:* node server.js

# Or add console.log statements
console.log('Request received:', req.method, req.path);
```

## Middleware Concepts

Your server includes several middleware examples:

### 1. JSON Parser
```javascript
app.use(express.json()); // Parse JSON request bodies
```

### 2. URL Encoder
```javascript
app.use(express.urlencoded({ extended: true })); // Parse form data
```

### 3. Custom Logger
```javascript
app.use((req, res, next) => {
  console.log(`${req.method} ${req.path}`);
  next(); // Continue to next middleware
});
```

### 4. Error Handler
```javascript
app.use((error, req, res, next) => {
  res.status(500).json({ error: error.message });
});
```

## Production Deployment

### Environment Variables
```javascript
// Use environment port or default to 3000
const PORT = process.env.PORT || 3000;
```

### Graceful Shutdown
```javascript
process.on('SIGTERM', () => {
  console.log('Shutting down gracefully...');
  process.exit(0);
});
```

## Next Steps

After mastering Express basics, you'll learn:

### 🚀 Tomorrow: Advanced Server Topics
- **Middleware** – Custom request processing
- **Authentication** – User login and sessions
- **Databases** – Storing and retrieving data
- **File Uploads** – Handling file uploads
- **WebSockets** – Real-time communication

### 📚 Recommended Learning Path
1. **Express Routing** – Advanced routing patterns
2. **Database Integration** – MongoDB, PostgreSQL
3. **Authentication** – JWT, sessions, OAuth
4. **API Design** – RESTful APIs, GraphQL
5. **Testing** – Unit tests, integration tests
6. **Deployment** – Heroku, AWS, Docker

## Troubleshooting Guide

### Server Won't Start
```bash
# Check Node.js version
node --version

# Check if port is available
netstat -an | grep 3000

# Try different port
PORT=3001 node server.js
```

### API Returns HTML Instead of JSON
- Check if you're requesting the correct endpoint
- Verify the route definition in server.js
- Make sure you're using GET method

### CORS Issues
If you get CORS errors when accessing from browser:
```javascript
// Add CORS middleware (for development)
npm install cors
const cors = require('cors');
app.use(cors());
```

## Additional Resources

### 📖 Official Documentation
- [Node.js Docs](https://nodejs.org/en/docs/)
- [Express.js Guide](https://expressjs.com/en/guide/routing.html)
- [npm Documentation](https://docs.npmjs.com/)

### 🛠️ Useful Tools
- **Postman** – API testing tool
- **Insomnia** – REST client
- **Thunder Client** – VS Code extension
- **nodemon** – Auto-restart for development

### 📚 Learning Resources
- **Express in Action** – Book
- **Node.js Best Practices** – GitHub repo
- **MDN Web Docs** – HTTP, APIs
- **freeCodeCamp** – Node.js curriculum

## Challenge Success Criteria

✅ **Minimum Requirements Met:**
- [ ] Server starts on port 3000
- [ ] `/api` route returns JSON with message
- [ ] `npm init` and `npm install express` completed
- [ ] Server runs without errors

✅ **Bonus Features Implemented:**
- [ ] Homepage with HTML interface
- [ ] Additional routes for learning
- [ ] Error handling and logging
- [ ] Graceful shutdown handling

## Congratulations! 🎉

You've successfully created your first Express server! This is a major milestone in your full-stack development journey. You now understand:

- ✅ How to create Node.js applications
- ✅ How to use npm for package management
- ✅ How to build Express servers
- ✅ How to handle HTTP requests and responses
- ✅ How to create API endpoints
- ✅ How to test and debug servers

**Keep building, keep learning, and keep creating amazing full-stack applications!** 🌟

---

*Day 7: Your First Server (Node.js & Express) - Full Stack Web Development Challenge*
